﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HouseClasses;

namespace Lab5_Menu
{
    public partial class Form1 : Form
    {
        HouseDatabase houseData;
        public Form1()
        {
            InitializeComponent();
            houseData = new HouseDatabase();
            cboSelectCity.DataSource = houseData.getHouses();
            cboSelectCity.SelectedIndex = 0;
            stpFile.Text += cboSelectCity.Text + ".jpg";
            stpDate.Text += DateTime.Now;
            picRealEstate.Image = Image.FromFile("Lab 5 Images/"+cboSelectCity.SelectedValue.ToString() + ".jpg");
        }

        private void mnuFileExit_Click(object sender, EventArgs e)
        {
            houseData.dropTable();
            Close();
        }

        private void mnuFileOpen_Click(object sender, EventArgs e)
        {
            ofdChangePic.Title = "Choose Pic to Display";
            ofdChangePic.InitialDirectory = System.IO.Path.Combine(Application.StartupPath, @"Lab 5 Images");
            ofdChangePic.FileName = "";
            ofdChangePic.Filter = "GIF files (*.gif)|*.gif;|JPG or PNG files (*.jpg) (*.png)|*.jpg;*.png;";
            ofdChangePic.FilterIndex = 2;
            if (ofdChangePic.ShowDialog()==DialogResult.OK)
            {
                picRealEstate.Image = Image.FromFile(ofdChangePic.FileName);
                string sub = ofdChangePic.SafeFileName.Replace(".jpg", "");
                cboSelectCity.Text = sub;
            }
        }

        private void cboSelectCity_SelectedIndexChanged(object sender, EventArgs e)
        {
            List<House> results = houseData.getHouseList(cboSelectCity.SelectedValue.ToString());
            foreach (House a in results) 
            {
                txtCity.Text = a.City;
                txtAddress.Text = a.Street;
                txtAskingPrice.Text = "$" + a.Price;
                txtZip.Text = a.Postal;
            }
            picRealEstate.Image = Image.FromFile("Lab 5 Images/" + cboSelectCity.SelectedValue.ToString() + ".jpg");
        }

        private void openPictureToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mnuFileOpen.PerformClick();
        }

        private void changeColourToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mnuFileColour.PerformClick();
        }

        private void mnuFileColour_Click(object sender, EventArgs e)
        {
            codColour.FullOpen = true;
            codColour.ShowDialog();
            this.ForeColor = codColour.Color;
        }
    }
}
