﻿namespace Lab5_Menu
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.cboSelectCity = new System.Windows.Forms.ComboBox();
            this.lblStreet = new System.Windows.Forms.Label();
            this.picRealEstate = new System.Windows.Forms.PictureBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.txtZip = new System.Windows.Forms.TextBox();
            this.Label4 = new System.Windows.Forms.Label();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.txtAskingPrice = new System.Windows.Forms.TextBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuFileOpen = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuFileColour = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuFileExit = new System.Windows.Forms.ToolStripMenuItem();
            this.codColour = new System.Windows.Forms.ColorDialog();
            this.ofdChangePic = new System.Windows.Forms.OpenFileDialog();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.stpFile = new System.Windows.Forms.ToolStripStatusLabel();
            this.stpDate = new System.Windows.Forms.ToolStripStatusLabel();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.openPictureToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.changeColourToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.picRealEstate)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // cboSelectCity
            // 
            this.cboSelectCity.FormattingEnabled = true;
            this.cboSelectCity.Location = new System.Drawing.Point(16, 57);
            this.cboSelectCity.Margin = new System.Windows.Forms.Padding(4);
            this.cboSelectCity.Name = "cboSelectCity";
            this.cboSelectCity.Size = new System.Drawing.Size(160, 24);
            this.cboSelectCity.TabIndex = 2;
            this.cboSelectCity.SelectedIndexChanged += new System.EventHandler(this.cboSelectCity_SelectedIndexChanged);
            // 
            // lblStreet
            // 
            this.lblStreet.Location = new System.Drawing.Point(16, 113);
            this.lblStreet.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblStreet.Name = "lblStreet";
            this.lblStreet.Size = new System.Drawing.Size(73, 20);
            this.lblStreet.TabIndex = 3;
            this.lblStreet.Text = "Address:";
            // 
            // picRealEstate
            // 
            this.picRealEstate.Location = new System.Drawing.Point(316, 46);
            this.picRealEstate.Margin = new System.Windows.Forms.Padding(4);
            this.picRealEstate.Name = "picRealEstate";
            this.picRealEstate.Size = new System.Drawing.Size(341, 226);
            this.picRealEstate.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picRealEstate.TabIndex = 18;
            this.picRealEstate.TabStop = false;
            // 
            // txtAddress
            // 
            this.txtAddress.BackColor = System.Drawing.SystemColors.Window;
            this.txtAddress.Location = new System.Drawing.Point(84, 110);
            this.txtAddress.Margin = new System.Windows.Forms.Padding(4);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(223, 22);
            this.txtAddress.TabIndex = 19;
            // 
            // Label2
            // 
            this.Label2.Location = new System.Drawing.Point(16, 154);
            this.Label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(43, 20);
            this.Label2.TabIndex = 20;
            this.Label2.Text = "City:";
            // 
            // txtZip
            // 
            this.txtZip.BackColor = System.Drawing.SystemColors.Window;
            this.txtZip.Location = new System.Drawing.Point(241, 150);
            this.txtZip.Margin = new System.Windows.Forms.Padding(4);
            this.txtZip.Name = "txtZip";
            this.txtZip.Size = new System.Drawing.Size(63, 22);
            this.txtZip.TabIndex = 23;
            // 
            // Label4
            // 
            this.Label4.Location = new System.Drawing.Point(188, 150);
            this.Label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(43, 20);
            this.Label4.TabIndex = 22;
            this.Label4.Text = "Zip:";
            // 
            // txtCity
            // 
            this.txtCity.BackColor = System.Drawing.SystemColors.Window;
            this.txtCity.Location = new System.Drawing.Point(81, 150);
            this.txtCity.Margin = new System.Windows.Forms.Padding(4);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(95, 22);
            this.txtCity.TabIndex = 21;
            // 
            // txtAskingPrice
            // 
            this.txtAskingPrice.BackColor = System.Drawing.SystemColors.Window;
            this.txtAskingPrice.Location = new System.Drawing.Point(111, 204);
            this.txtAskingPrice.Margin = new System.Windows.Forms.Padding(4);
            this.txtAskingPrice.Name = "txtAskingPrice";
            this.txtAskingPrice.Size = new System.Drawing.Size(105, 22);
            this.txtAskingPrice.TabIndex = 25;
            this.txtAskingPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Label3
            // 
            this.Label3.Location = new System.Drawing.Point(16, 208);
            this.Label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(139, 20);
            this.Label3.TabIndex = 24;
            this.Label3.Text = "Asking price:";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(671, 28);
            this.menuStrip1.TabIndex = 26;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFileOpen,
            this.mnuFileColour,
            this.mnuFileExit});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(44, 24);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // mnuFileOpen
            // 
            this.mnuFileOpen.Name = "mnuFileOpen";
            this.mnuFileOpen.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.mnuFileOpen.Size = new System.Drawing.Size(222, 26);
            this.mnuFileOpen.Text = "Open Picture";
            this.mnuFileOpen.Click += new System.EventHandler(this.mnuFileOpen_Click);
            // 
            // mnuFileColour
            // 
            this.mnuFileColour.Name = "mnuFileColour";
            this.mnuFileColour.Size = new System.Drawing.Size(222, 26);
            this.mnuFileColour.Text = "Change Colour";
            this.mnuFileColour.Click += new System.EventHandler(this.mnuFileColour_Click);
            // 
            // mnuFileExit
            // 
            this.mnuFileExit.Name = "mnuFileExit";
            this.mnuFileExit.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.E)));
            this.mnuFileExit.Size = new System.Drawing.Size(222, 26);
            this.mnuFileExit.Text = "Exit";
            this.mnuFileExit.Click += new System.EventHandler(this.mnuFileExit_Click);
            // 
            // ofdChangePic
            // 
            this.ofdChangePic.FileName = "openFileDialog1";
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stpFile,
            this.stpDate});
            this.statusStrip1.Location = new System.Drawing.Point(0, 272);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(671, 25);
            this.statusStrip1.TabIndex = 27;
            this.statusStrip1.Text = "sstInfo";
            // 
            // stpFile
            // 
            this.stpFile.Margin = new System.Windows.Forms.Padding(0, 3, 200, 2);
            this.stpFile.Name = "stpFile";
            this.stpFile.Size = new System.Drawing.Size(79, 20);
            this.stpFile.Text = "File Name:";
            // 
            // stpDate
            // 
            this.stpDate.Name = "stpDate";
            this.stpDate.Size = new System.Drawing.Size(45, 20);
            this.stpDate.Text = "Time:";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openPictureToolStripMenuItem,
            this.changeColourToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(177, 52);
            // 
            // openPictureToolStripMenuItem
            // 
            this.openPictureToolStripMenuItem.Name = "openPictureToolStripMenuItem";
            this.openPictureToolStripMenuItem.Size = new System.Drawing.Size(176, 24);
            this.openPictureToolStripMenuItem.Text = "Open Picture";
            this.openPictureToolStripMenuItem.Click += new System.EventHandler(this.openPictureToolStripMenuItem_Click);
            // 
            // changeColourToolStripMenuItem
            // 
            this.changeColourToolStripMenuItem.Name = "changeColourToolStripMenuItem";
            this.changeColourToolStripMenuItem.Size = new System.Drawing.Size(176, 24);
            this.changeColourToolStripMenuItem.Text = "Change Colour";
            this.changeColourToolStripMenuItem.Click += new System.EventHandler(this.changeColourToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(671, 297);
            this.ContextMenuStrip = this.contextMenuStrip1;
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.txtAskingPrice);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.txtZip);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.txtCity);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.picRealEstate);
            this.Controls.Add(this.lblStreet);
            this.Controls.Add(this.cboSelectCity);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "House View";
            ((System.ComponentModel.ISupportInitialize)(this.picRealEstate)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cboSelectCity;
        internal System.Windows.Forms.Label lblStreet;
        internal System.Windows.Forms.PictureBox picRealEstate;
        internal System.Windows.Forms.TextBox txtAddress;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.TextBox txtZip;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.TextBox txtCity;
        internal System.Windows.Forms.TextBox txtAskingPrice;
        internal System.Windows.Forms.Label Label3;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mnuFileOpen;
        private System.Windows.Forms.ToolStripMenuItem mnuFileExit;
        private System.Windows.Forms.ToolStripMenuItem mnuFileColour;
        private System.Windows.Forms.ColorDialog codColour;
        private System.Windows.Forms.OpenFileDialog ofdChangePic;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel stpFile;
        private System.Windows.Forms.ToolStripStatusLabel stpDate;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem openPictureToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem changeColourToolStripMenuItem;
    }
}

