﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Oracle.ManagedDataAccess.Client;

namespace HouseClasses
{
    public class HouseDatabase
    {
        private const string HOST = "calvin.humber.ca";
        private const string SID = "grok";
        internal const string PASSWORD = "oracle";
        private const string USER_ID = "N01190454";

        private static readonly string strCONNECTIONSTRING = string.Format("DATA SOURCE=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)" +
                                                            "(HOST={0})(PORT=1521))(CONNECT_DATA=(SID={1}))); " +
                                                            "PASSWORD={2}; USER ID={3}", HOST, SID, PASSWORD, USER_ID);
        private OracleConnection oracleConnect = new OracleConnection(strCONNECTIONSTRING);
        private OracleCommand oracleCommand = new OracleCommand();
        private OracleDataReader oracleReader;

        public HouseDatabase()
        {
            oracleCommand.Connection = oracleConnect;
            oracleConnect.Open();
            createTable(oracleCommand);
        }

        public void createTable(OracleCommand oracleCommand)
        {
            try
            {

                {
                    oracleCommand.CommandText = "create table HOUSETABLE (CITY varchar2(20), ADDRESS varchar2(100), POSTAL_CODE varchar2(9), PRICE varchar2(10))";
                    oracleCommand.ExecuteNonQuery();
                    oracleCommand.CommandText = "insert into HOUSETABLE values ('Glendale', '35 Twin Oaks', 'M0N6L3', '328743.0')";
                    oracleCommand.ExecuteNonQuery();
                    oracleCommand.CommandText = "insert into HOUSETABLE values ('Oakdale', '20 Helen Drive', 'G6L5M4', '455899.0')";
                    oracleCommand.ExecuteNonQuery();
                    oracleCommand.CommandText = "insert into HOUSETABLE values ('Markham', '7 Shady Oaks', 'L4R3L9', '379099.0')";
                    oracleCommand.ExecuteNonQuery();
                    oracleCommand.CommandText = "insert into HOUSETABLE values ('Mississauga', '1 Ocean Ridge', 'L4T0A1', '589999.0')";
                    oracleCommand.ExecuteNonQuery();
                    oracleCommand.CommandText = "insert into HOUSETABLE values ('Brampton', '4 RiverBank Rd', 'L9H4L2', '699999.0')";
                    oracleCommand.ExecuteNonQuery();
                }
            }
            catch (Exception objException)
            {
                dropTable();
                oracleCommand.Connection = oracleConnect;
                oracleConnect.Open();
                createTable(oracleCommand);
            }
        }

        public void dropTable()
        {
            oracleCommand.CommandText = "drop table HOUSETABLE";
            oracleCommand.ExecuteNonQuery();
            oracleConnect.Close();
        }

        public List<string> getHouses()
        {
            List<string> houses = new List<string>();
            oracleCommand.CommandText = "select distinct CITY from HOUSETABLE";
            oracleReader = oracleCommand.ExecuteReader();

            while (oracleReader.Read())
            {
                houses.Add(oracleReader["CITY"].ToString());
            }
            oracleReader.Close();
            return houses;
        }

        public List<House> getHouseList(string city)
        {
            List<House> houseList = new List<House>();
            oracleCommand.CommandText = "select * from HOUSETABLE where CITY = '" + city +"'";
            oracleReader = oracleCommand.ExecuteReader();

            while (oracleReader.Read())
            {
                House thisOne = new House();
                thisOne.Postal = oracleReader["POSTAL_CODE"].ToString();
                thisOne.Street = oracleReader["ADDRESS"].ToString();
                thisOne.City = oracleReader["CITY"].ToString();
                thisOne.Price = oracleReader["PRICE"].ToString();
                houseList.Add(thisOne);
            }
            oracleReader.Close();
            return houseList;
        }



    }
}
