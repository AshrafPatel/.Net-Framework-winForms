﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HouseClasses
{
    public class House
    {
        //These are automatic properties – you can use them if you 
        //don’t need special editing in the getter or setter
        public string Price { get; set; }
        public string Street { get; set; }
        public string City { get; set; }
        public string Postal { get; set; }
        public string Picture { get; set; }

        public House()
        {

        }
        public House (string price, string street, string city, string postal, string picture)
        {
            Price = price;
            Street = street;
            City = city;
            Postal = postal; 
            Picture = picture;
        }
    }
}
