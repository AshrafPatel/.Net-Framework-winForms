﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CakeClasses
{
    public class Cake
    {
        //Variables
        private const int intPRICE = 20;                   //Cake default price is 20
        public const double dblTAX = 1.13;                 //Tax is constant

        //Properties
        public int Price { get; set; }                      //Creating a price property to change price for cakes

        //Method
        public virtual string calculatePrice()  //To calculate price to get totals
        {
            string a = (intPRICE * dblTAX).ToString("C");
            return a;
        }
    }
}
