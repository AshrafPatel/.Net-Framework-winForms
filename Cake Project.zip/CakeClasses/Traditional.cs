﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CakeClasses
{
    public class Traditional : Cake
    {
        //Variables
        public const int intSTRAWCAKE  = 22;
        public const int intBLUEMOUSSE = 20;
        public const int intLEMONCAKE  = 25;
        public const int intTIRA       = 30;

        //Properties
        public string FlavourType { get; set; }         //Property for flavours

        //Methods
        public Traditional(string flavour) : base()
        {
            FlavourType = flavour;
        }

        public int changingPrice()          //Creating method to change prices and return new price
        {
            if (FlavourType == "Strawberry Cheese Cake") { Price = intSTRAWCAKE; }
            else if (FlavourType == "Blueberry Mousse")  { Price = intBLUEMOUSSE; }
            else if (FlavourType == "Lemon Velvet Cake") { Price = intLEMONCAKE; }
            else if (FlavourType == "Tiramisu")          { Price = intTIRA; }
            return Price;
        }

        public override string calculatePrice()  //overriding the method in Cake class
        {
            string a = (changingPrice() * dblTAX).ToString("C");
            return a;
        }

        public override string ToString()
        {
            return FlavourType
                  + "\nat the price of " + changingPrice().ToString("C")
                  + "\nfor the total cost of " + calculatePrice();      //calling method calculate price
        }
    }
}
