﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CakeClasses
{
    public class Order
    {
        //Variables
        private int intRandom;                      //Integer variable which will be changed to random number

        //Properties
        public Customer Customer { get; set; }      //Customer object property
        public Cake Cake { get; set; }              //Cake object property
        public int Random                           //Random property to get the random number
        {
            get                                     //Getter for Random property
            {
                Random rand = new Random();
                intRandom = rand.Next(10000, 999999);
                return intRandom;
            }
        }

        //Methods
        public Order(Customer objCustomer, Cake objCake)    //Order Object takes Customer Property and Cake Property
        {
            Customer = objCustomer;
            Cake = objCake;
        }

        public string orderLabel()  //The code for changing lblOrder.Text when order has been successful
        {
            return "\nYour order has"
                 + "\nbeen placed"
                 + "\nYour confirmation"
                 + "\ncode is:"
                 + "\n" + Random;
        }

        public string orderCancel()//The code for changing lblOrder.Text when order has been cancelled
        {
            return "Your order has \nbeen cancelled";
        }

        public override string ToString()//The code for prompt box
        {
            return Customer.ToString()
                 + "\nYou have ordered 1 " + Cake.ToString();
        }
    }
}
