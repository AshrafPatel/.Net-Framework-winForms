﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CakeClasses
{
    public class Customer
    {
        //Properties
        public string FirstName { get; set; }
        public string LastName { get; set; }


        //Methods
        public Customer(string fName, string lName)     //Customer object takes two string for first and last name
        {
            FirstName = fName;
            LastName = lName;
        }

        public override String ToString()           //ToString used to get Customer full name
        {
            return FirstName + " " + LastName;
        }
    }
}
