﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CakeClasses
{
    public class Custom : Cake
    {
        //Variables
        public const int intTONE = 23;          //Constants for Tier Cakes
        public const int intTTWO = 26;
        public const int intTTRE = 29;

        //Properties
        public string Flavour { get; set; }     //Properties for Flavour, Occasion, Tier
        public string Occasion { get; set; }
        public string Tier { get; set; }


        //Methods
        public Custom(string flav, string occ, string tie) : base()         //to create custom object need 3 properties
        {                                                                   //Flavour, Occasion, Tier
            Flavour = flav;
            Occasion = occ;
            Tier = tie;
        }

        public int changingPrice()                                          //The method will return new price
        {
            if (Tier == "1 Tier") { Price = intTONE; }              //intPrice inherited from Cake class
            else if (Tier == "2 Tiers") { Price = intTTWO; }        //intPRice changes dependant on Tiers
            else if (Tier == "3 Tiers") { Price = intTTRE; }
            return Price;
        }

        public override string calculatePrice()     //Overiding calculate method in Cake class
        {
            string a = (changingPrice() * dblTAX).ToString("C");
            return a;
        }

        public override string ToString()   //To string used to get generic message 
        {
            return Occasion + ", " + "\n" + Flavour + " flavoured cake with " + Tier
                 + "\nfor the total cost of " + calculatePrice();
        }
    }
}
