﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CakeClasses;

namespace ProjectCake
{
    public partial class frmBakery : Form
    {
        Order objOrder;                                 //Order object initialised
        Cake objCake;                                   //Cake object only used for custom cake

        public frmBakery()
        {
            InitializeComponent();
            cboCakeList.SelectedIndex = 0;
            objCake = new Custom(radChocolate.Text, radAnniversary.Text, radThree.Text);//create default custom cake
        }

        private void radCustom_CheckedChanged(object sender, EventArgs e)
        {
            cboCakeList.Enabled = false;                                    //ComboBox Disabled       
            grpCustom.Enabled = true;                                       //GroupBox Enabled
            grpCustom.BackColor = Color.Empty;                              //Reset Color of GroupBox
            cboCakeList.BackColor = Color.FromArgb(0, 128, 128);            //Changing color of Combo Box to be a little faded
            objCake = new Custom(radChocolate.Text, radAnniversary.Text, radThree.Text);//When custom checked create default cake
        }

        private void radTraditional_CheckedChanged(object sender, EventArgs e)
        {
            cboCakeList.Enabled = true;                                     //ComboBox Enabled
            grpCustom.Enabled = false;                                      //GroupBox Disabled
            grpCustom.BackColor = Color.FromArgb(75, 128, 128);             //Changing color of Group Box to be a little faded
            cboCakeList.BackColor = Color.Empty;                            //Reset Color of Combo Box
        }

        private void btnOrder_Click(object sender, EventArgs e)
        {
            DialogResult dlgResult = 0;                 //Creating Dialog object to use later in method

            //Name is not Entered Code
            if (String.IsNullOrEmpty(txtFirstName.Text) || String.IsNullOrEmpty(txtLastName.Text))
            {
                MessageBox.Show("Name is not valid \nPlease try again");
            }

            //Radio buttons not checked Code --Custom/Traditional--
            else if (!radCustom.Checked && !radTraditional.Checked)
            {
                MessageBox.Show("Please choose Custom or Traditional");
            }

     
            //Traditional Cake selected
            else if (radTraditional.Checked)
            {
                if (radTraditional.Checked && cboCakeList.SelectedItem != null)
                {
                    objOrder = new Order(new Customer(txtFirstName.Text, txtLastName.Text)
                             , new Traditional(cboCakeList.SelectedItem.ToString()));
                    dlgResult = MessageBox.Show(objOrder.ToString(), "Your Order",
                                MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
                    lblOrder.Visible = true;
                }
                if (dlgResult == DialogResult.Yes) { lblOrder.Text = objOrder.Customer + objOrder.orderLabel(); }
                else { lblOrder.Text = "Your order has \nbeen cancelled"; }
            }

            //Custom Cake selected
            else if (radCustom.Checked)
            {
                objOrder = new Order(new Customer(txtFirstName.Text, txtLastName.Text), objCake);
                dlgResult = MessageBox.Show(objOrder.ToString(), "Your Order",
                            MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
                lblOrder.Visible = true;
                if (dlgResult == DialogResult.Yes) { lblOrder.Text = objOrder.Customer + objOrder.orderLabel(); }
                else { lblOrder.Text = "Your order has \nbeen cancelled"; }
            }
            
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtFirstName.Clear();               //Clearing name textform
            txtLastName.Clear();                
            lblOrder.Visible = false;           //Want to hide the order confirmation label
            radChocolate.Checked = false;       //Unchecking all radio buttons
            radVanilla.Checked = false;
            radStrawberry.Checked = false;
            radCustom.Checked = false;
            radTraditional.Checked = false;
            radAnniversary.Checked = false;
            radGraduation.Checked = false;
            radWedding.Checked = false;
            radOne.Checked = false;
            radTwo.Checked = false;
            radThree.Checked = false;
            cboCakeList.SelectedIndex = -1;      //ComboList Box reset
        }

        private void radChocolate_CheckedChanged(object sender, EventArgs e)
        {
            ((Custom)objCake).Flavour = radChocolate.Text;  //Using radio checked events to change Flavour, Occasion an Tier props
        }

        private void radVanilla_CheckedChanged(object sender, EventArgs e)
        {
            ((Custom)objCake).Flavour = radVanilla.Text;
        }

        private void radStrawberry_CheckedChanged(object sender, EventArgs e)
        {
            ((Custom)objCake).Flavour = radStrawberry.Text;
        }

        private void radWedding_CheckedChanged(object sender, EventArgs e)
        {
            ((Custom)objCake).Occasion = radWedding.Text;
        }

        private void radAnniversary_CheckedChanged(object sender, EventArgs e)
        {
            ((Custom)objCake).Occasion = radAnniversary.Text;
        }

        private void radGraduation_CheckedChanged(object sender, EventArgs e)
        {
            ((Custom)objCake).Occasion = radGraduation.Text;
        }

        private void radOne_CheckedChanged(object sender, EventArgs e)
        {
            ((Custom)objCake).Tier = "1 Tier";
        }

        private void radTwo_CheckedChanged(object sender, EventArgs e)
        {
            ((Custom)objCake).Tier = "2 Tiers";
        }

        private void radThree_CheckedChanged(object sender, EventArgs e)
        {
            ((Custom)objCake).Tier = "3 Tiers";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();                                        //Exit Application
        }
    }
}
