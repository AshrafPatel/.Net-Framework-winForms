﻿namespace ProjectCake
{
    partial class frmBakery
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpCustInfo = new System.Windows.Forms.GroupBox();
            this.lblLastName = new System.Windows.Forms.Label();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.lblTitle = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radTraditional = new System.Windows.Forms.RadioButton();
            this.radCustom = new System.Windows.Forms.RadioButton();
            this.lblCakeList = new System.Windows.Forms.Label();
            this.cboCakeList = new System.Windows.Forms.ComboBox();
            this.grpCustom = new System.Windows.Forms.GroupBox();
            this.grpTiers = new System.Windows.Forms.GroupBox();
            this.radThree = new System.Windows.Forms.RadioButton();
            this.radTwo = new System.Windows.Forms.RadioButton();
            this.radOne = new System.Windows.Forms.RadioButton();
            this.grpFlavour = new System.Windows.Forms.GroupBox();
            this.radStrawberry = new System.Windows.Forms.RadioButton();
            this.radVanilla = new System.Windows.Forms.RadioButton();
            this.radChocolate = new System.Windows.Forms.RadioButton();
            this.grpOccasion = new System.Windows.Forms.GroupBox();
            this.radGraduation = new System.Windows.Forms.RadioButton();
            this.radAnniversary = new System.Windows.Forms.RadioButton();
            this.radWedding = new System.Windows.Forms.RadioButton();
            this.btnOrder = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.lblOrder = new System.Windows.Forms.Label();
            this.grpCustInfo.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.grpCustom.SuspendLayout();
            this.grpTiers.SuspendLayout();
            this.grpFlavour.SuspendLayout();
            this.grpOccasion.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpCustInfo
            // 
            this.grpCustInfo.Controls.Add(this.lblLastName);
            this.grpCustInfo.Controls.Add(this.lblFirstName);
            this.grpCustInfo.Controls.Add(this.txtFirstName);
            this.grpCustInfo.Controls.Add(this.txtLastName);
            this.grpCustInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpCustInfo.Location = new System.Drawing.Point(21, 65);
            this.grpCustInfo.Name = "grpCustInfo";
            this.grpCustInfo.Size = new System.Drawing.Size(423, 159);
            this.grpCustInfo.TabIndex = 0;
            this.grpCustInfo.TabStop = false;
            this.grpCustInfo.Text = "Customer Information";
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLastName.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lblLastName.Location = new System.Drawing.Point(6, 100);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(134, 29);
            this.lblLastName.TabIndex = 5;
            this.lblLastName.Text = "&Last Name:";
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFirstName.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lblFirstName.Location = new System.Drawing.Point(6, 42);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(137, 29);
            this.lblFirstName.TabIndex = 4;
            this.lblFirstName.Text = "&First Name:";
            // 
            // txtFirstName
            // 
            this.txtFirstName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFirstName.Location = new System.Drawing.Point(223, 40);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(194, 34);
            this.txtFirstName.TabIndex = 0;
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(223, 97);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(194, 34);
            this.txtLastName.TabIndex = 1;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Monotype Corsiva", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(430, -10);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(316, 72);
            this.lblTitle.TabIndex = 18;
            this.lblTitle.Text = "asAP Bakery";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radTraditional);
            this.groupBox1.Controls.Add(this.radCustom);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(518, 65);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(341, 89);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Type Of Cake";
            // 
            // radTraditional
            // 
            this.radTraditional.AutoSize = true;
            this.radTraditional.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radTraditional.Location = new System.Drawing.Point(171, 38);
            this.radTraditional.Name = "radTraditional";
            this.radTraditional.Size = new System.Drawing.Size(149, 33);
            this.radTraditional.TabIndex = 1;
            this.radTraditional.TabStop = true;
            this.radTraditional.Text = "Traditional";
            this.radTraditional.UseVisualStyleBackColor = true;
            this.radTraditional.CheckedChanged += new System.EventHandler(this.radTraditional_CheckedChanged);
            // 
            // radCustom
            // 
            this.radCustom.AutoSize = true;
            this.radCustom.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radCustom.Location = new System.Drawing.Point(17, 38);
            this.radCustom.Name = "radCustom";
            this.radCustom.Size = new System.Drawing.Size(116, 33);
            this.radCustom.TabIndex = 0;
            this.radCustom.TabStop = true;
            this.radCustom.Text = "Custom";
            this.radCustom.UseVisualStyleBackColor = true;
            this.radCustom.CheckedChanged += new System.EventHandler(this.radCustom_CheckedChanged);
            // 
            // lblCakeList
            // 
            this.lblCakeList.AutoSize = true;
            this.lblCakeList.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCakeList.Location = new System.Drawing.Point(513, 157);
            this.lblCakeList.Name = "lblCakeList";
            this.lblCakeList.Size = new System.Drawing.Size(233, 29);
            this.lblCakeList.TabIndex = 2;
            this.lblCakeList.Text = "Traditional Cake List";
            // 
            // cboCakeList
            // 
            this.cboCakeList.BackColor = System.Drawing.SystemColors.Window;
            this.cboCakeList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboCakeList.FormattingEnabled = true;
            this.cboCakeList.Items.AddRange(new object[] {
            "Strawberry Cheese Cake",
            "Blueberry Mousse",
            "Lemon Velvet Cake",
            "Tiramisu"});
            this.cboCakeList.Location = new System.Drawing.Point(518, 200);
            this.cboCakeList.Name = "cboCakeList";
            this.cboCakeList.Size = new System.Drawing.Size(341, 24);
            this.cboCakeList.TabIndex = 3;
            // 
            // grpCustom
            // 
            this.grpCustom.Controls.Add(this.grpTiers);
            this.grpCustom.Controls.Add(this.grpFlavour);
            this.grpCustom.Controls.Add(this.grpOccasion);
            this.grpCustom.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpCustom.Location = new System.Drawing.Point(21, 248);
            this.grpCustom.Name = "grpCustom";
            this.grpCustom.Size = new System.Drawing.Size(838, 265);
            this.grpCustom.TabIndex = 4;
            this.grpCustom.TabStop = false;
            this.grpCustom.Text = "Custom Cake";
            // 
            // grpTiers
            // 
            this.grpTiers.Controls.Add(this.radThree);
            this.grpTiers.Controls.Add(this.radTwo);
            this.grpTiers.Controls.Add(this.radOne);
            this.grpTiers.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpTiers.Location = new System.Drawing.Point(562, 39);
            this.grpTiers.Name = "grpTiers";
            this.grpTiers.Size = new System.Drawing.Size(246, 209);
            this.grpTiers.TabIndex = 2;
            this.grpTiers.TabStop = false;
            this.grpTiers.Text = "&Number of Tier(s)";
            // 
            // radThree
            // 
            this.radThree.AutoSize = true;
            this.radThree.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radThree.Location = new System.Drawing.Point(40, 153);
            this.radThree.Name = "radThree";
            this.radThree.Size = new System.Drawing.Size(171, 33);
            this.radThree.TabIndex = 2;
            this.radThree.TabStop = true;
            this.radThree.Text = "3 Tiers Cake";
            this.radThree.UseVisualStyleBackColor = true;
            this.radThree.CheckedChanged += new System.EventHandler(this.radThree_CheckedChanged);
            // 
            // radTwo
            // 
            this.radTwo.AutoSize = true;
            this.radTwo.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radTwo.Location = new System.Drawing.Point(40, 98);
            this.radTwo.Name = "radTwo";
            this.radTwo.Size = new System.Drawing.Size(171, 33);
            this.radTwo.TabIndex = 1;
            this.radTwo.TabStop = true;
            this.radTwo.Text = "2 Tiers Cake";
            this.radTwo.UseVisualStyleBackColor = true;
            this.radTwo.CheckedChanged += new System.EventHandler(this.radTwo_CheckedChanged);
            // 
            // radOne
            // 
            this.radOne.AutoSize = true;
            this.radOne.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radOne.Location = new System.Drawing.Point(40, 46);
            this.radOne.Name = "radOne";
            this.radOne.Size = new System.Drawing.Size(159, 33);
            this.radOne.TabIndex = 0;
            this.radOne.TabStop = true;
            this.radOne.Text = "1 Tier Cake";
            this.radOne.UseVisualStyleBackColor = true;
            this.radOne.CheckedChanged += new System.EventHandler(this.radOne_CheckedChanged);
            // 
            // grpFlavour
            // 
            this.grpFlavour.Controls.Add(this.radStrawberry);
            this.grpFlavour.Controls.Add(this.radVanilla);
            this.grpFlavour.Controls.Add(this.radChocolate);
            this.grpFlavour.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpFlavour.Location = new System.Drawing.Point(22, 39);
            this.grpFlavour.Name = "grpFlavour";
            this.grpFlavour.Size = new System.Drawing.Size(231, 209);
            this.grpFlavour.TabIndex = 0;
            this.grpFlavour.TabStop = false;
            this.grpFlavour.Text = "&Flavour";
            // 
            // radStrawberry
            // 
            this.radStrawberry.AutoSize = true;
            this.radStrawberry.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radStrawberry.Location = new System.Drawing.Point(37, 153);
            this.radStrawberry.Name = "radStrawberry";
            this.radStrawberry.Size = new System.Drawing.Size(150, 33);
            this.radStrawberry.TabIndex = 2;
            this.radStrawberry.TabStop = true;
            this.radStrawberry.Text = "Strawberry";
            this.radStrawberry.UseVisualStyleBackColor = true;
            this.radStrawberry.CheckedChanged += new System.EventHandler(this.radStrawberry_CheckedChanged);
            // 
            // radVanilla
            // 
            this.radVanilla.AutoSize = true;
            this.radVanilla.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radVanilla.Location = new System.Drawing.Point(37, 98);
            this.radVanilla.Name = "radVanilla";
            this.radVanilla.Size = new System.Drawing.Size(106, 33);
            this.radVanilla.TabIndex = 1;
            this.radVanilla.TabStop = true;
            this.radVanilla.Text = "Vanilla";
            this.radVanilla.UseVisualStyleBackColor = true;
            this.radVanilla.CheckedChanged += new System.EventHandler(this.radVanilla_CheckedChanged);
            // 
            // radChocolate
            // 
            this.radChocolate.AutoSize = true;
            this.radChocolate.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radChocolate.Location = new System.Drawing.Point(37, 46);
            this.radChocolate.Name = "radChocolate";
            this.radChocolate.Size = new System.Drawing.Size(143, 33);
            this.radChocolate.TabIndex = 0;
            this.radChocolate.TabStop = true;
            this.radChocolate.Text = "Chocolate";
            this.radChocolate.UseVisualStyleBackColor = true;
            this.radChocolate.CheckedChanged += new System.EventHandler(this.radChocolate_CheckedChanged);
            // 
            // grpOccasion
            // 
            this.grpOccasion.Controls.Add(this.radGraduation);
            this.grpOccasion.Controls.Add(this.radAnniversary);
            this.grpOccasion.Controls.Add(this.radWedding);
            this.grpOccasion.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpOccasion.Location = new System.Drawing.Point(288, 39);
            this.grpOccasion.Name = "grpOccasion";
            this.grpOccasion.Size = new System.Drawing.Size(242, 209);
            this.grpOccasion.TabIndex = 1;
            this.grpOccasion.TabStop = false;
            this.grpOccasion.Text = "&Occasion";
            // 
            // radGraduation
            // 
            this.radGraduation.AutoSize = true;
            this.radGraduation.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radGraduation.Location = new System.Drawing.Point(36, 153);
            this.radGraduation.Name = "radGraduation";
            this.radGraduation.Size = new System.Drawing.Size(152, 33);
            this.radGraduation.TabIndex = 2;
            this.radGraduation.TabStop = true;
            this.radGraduation.Text = "Graduation";
            this.radGraduation.UseVisualStyleBackColor = true;
            this.radGraduation.CheckedChanged += new System.EventHandler(this.radGraduation_CheckedChanged);
            // 
            // radAnniversary
            // 
            this.radAnniversary.AutoSize = true;
            this.radAnniversary.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radAnniversary.Location = new System.Drawing.Point(36, 98);
            this.radAnniversary.Name = "radAnniversary";
            this.radAnniversary.Size = new System.Drawing.Size(158, 33);
            this.radAnniversary.TabIndex = 1;
            this.radAnniversary.TabStop = true;
            this.radAnniversary.Text = "Anniversary";
            this.radAnniversary.UseVisualStyleBackColor = true;
            this.radAnniversary.CheckedChanged += new System.EventHandler(this.radAnniversary_CheckedChanged);
            // 
            // radWedding
            // 
            this.radWedding.AutoSize = true;
            this.radWedding.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radWedding.Location = new System.Drawing.Point(36, 46);
            this.radWedding.Name = "radWedding";
            this.radWedding.Size = new System.Drawing.Size(131, 33);
            this.radWedding.TabIndex = 0;
            this.radWedding.TabStop = true;
            this.radWedding.Text = "Wedding";
            this.radWedding.UseVisualStyleBackColor = true;
            this.radWedding.CheckedChanged += new System.EventHandler(this.radWedding_CheckedChanged);
            // 
            // btnOrder
            // 
            this.btnOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOrder.Location = new System.Drawing.Point(888, 85);
            this.btnOrder.Name = "btnOrder";
            this.btnOrder.Size = new System.Drawing.Size(239, 37);
            this.btnOrder.TabIndex = 5;
            this.btnOrder.Text = "&Order";
            this.btnOrder.UseVisualStyleBackColor = true;
            this.btnOrder.Click += new System.EventHandler(this.btnOrder_Click);
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(888, 190);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(239, 34);
            this.btnExit.TabIndex = 7;
            this.btnExit.Text = "&Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnClear
            // 
            this.btnClear.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(888, 139);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(239, 34);
            this.btnClear.TabIndex = 6;
            this.btnClear.Text = "&Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // lblOrder
            // 
            this.lblOrder.AutoSize = true;
            this.lblOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOrder.Location = new System.Drawing.Point(906, 267);
            this.lblOrder.MinimumSize = new System.Drawing.Size(200, 246);
            this.lblOrder.Name = "lblOrder";
            this.lblOrder.Size = new System.Drawing.Size(200, 246);
            this.lblOrder.TabIndex = 6;
            this.lblOrder.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lblOrder.Visible = false;
            // 
            // frmBakery
            // 
            this.AcceptButton = this.btnOrder;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.CancelButton = this.btnClear;
            this.ClientSize = new System.Drawing.Size(1154, 525);
            this.Controls.Add(this.lblOrder);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnOrder);
            this.Controls.Add(this.grpCustom);
            this.Controls.Add(this.cboCakeList);
            this.Controls.Add(this.lblCakeList);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.grpCustInfo);
            this.Name = "frmBakery";
            this.Text = "Ashraf Patel Bakery";
            this.grpCustInfo.ResumeLayout(false);
            this.grpCustInfo.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.grpCustom.ResumeLayout(false);
            this.grpTiers.ResumeLayout(false);
            this.grpTiers.PerformLayout();
            this.grpFlavour.ResumeLayout(false);
            this.grpFlavour.PerformLayout();
            this.grpOccasion.ResumeLayout(false);
            this.grpOccasion.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpCustInfo;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radTraditional;
        private System.Windows.Forms.RadioButton radCustom;
        private System.Windows.Forms.Label lblCakeList;
        private System.Windows.Forms.ComboBox cboCakeList;
        private System.Windows.Forms.GroupBox grpCustom;
        private System.Windows.Forms.GroupBox grpTiers;
        private System.Windows.Forms.GroupBox grpFlavour;
        private System.Windows.Forms.GroupBox grpOccasion;
        private System.Windows.Forms.RadioButton radStrawberry;
        private System.Windows.Forms.RadioButton radVanilla;
        private System.Windows.Forms.RadioButton radChocolate;
        private System.Windows.Forms.RadioButton radAnniversary;
        private System.Windows.Forms.RadioButton radWedding;
        private System.Windows.Forms.RadioButton radGraduation;
        private System.Windows.Forms.RadioButton radTwo;
        private System.Windows.Forms.RadioButton radOne;
        private System.Windows.Forms.RadioButton radThree;
        private System.Windows.Forms.Button btnOrder;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label lblOrder;
    }
}

